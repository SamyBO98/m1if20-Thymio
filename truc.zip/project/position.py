from enum import Enum
class Position(Enum):
    MIDDLE = "MIDDLE" # Par defaut
    LEFT = "LEFT" # Positionne a gauche
    RIGHT = "RIGHT" # Positionne a droite